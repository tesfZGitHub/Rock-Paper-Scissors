def play(player1, player2, num_games, verbose=False):
    p1_prev, p2_prev = "", ""
    p1_history, p2_history = [], []
    p1_wins, p2_wins = 0, 0

    for i in range(num_games):
        p1_move = player1(p2_prev, p1_history)
        p2_move = player2(p1_prev, p2_history)
        
        p1_history.append(p1_move)
        p2_history.append(p2_move)
        
        if beats(p1_move, p2_move):
            p1_wins += 1
            outcome = "Player 1 wins!"
        elif beats(p2_move, p1_move):
            p2_wins += 1
            outcome = "Player 2 wins!"
        else:
            outcome = "Tie!"
        
        if verbose:
            print(f"Round {i+1}: Player 1: {p1_move} | Player 2: {p2_move} -> {outcome}")
        
        p1_prev, p2_prev = p1_move, p2_move

    print(f"Final Score: Player 1: {p1_wins} | Player 2: {p2_wins}")

def beats(one, two):
    return (one == "R" and two == "S") or (one == "S" and two == "P") or (one == "P" and two == "R")

def quincy(prev_play, opponent_history=[]):
    return "R"

def mrugesh(prev_play, opponent_history=[]):
    if prev_play in ['R', 'P', 'S']:
        opponent_history.append(prev_play)
    most_common = max(set(opponent_history), key=opponent_history.count) if opponent_history else "R"
    return "P" if most_common == "R" else "S" if most_common == "P" else "R"

def kris(prev_play, opponent_history=[]):
    if prev_play in ['R', 'P', 'S']:
        opponent_history.append(prev_play)
    last_ten = opponent_history[-10:]
    most_common = max(set(last_ten), key=last_ten.count) if last_ten else "R"
    return "P" if most_common == "R" else "S" if most_common == "P" else "R"

def abbey(prev_play, opponent_history=[]):
    if prev_play in ['R', 'P', 'S']:
        opponent_history.append(prev_play)
    return opponent_history[-1] if opponent_history else "R"
