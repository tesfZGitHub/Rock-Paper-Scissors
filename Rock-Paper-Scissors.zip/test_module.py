import unittest
from RPS import player
from RPS_game import play, quincy, mrugesh, kris, abbey

class TestRockPaperScissors(unittest.TestCase):
    def test_quincy(self):
        result = play(player, quincy, 1000)
        self.assertGreaterEqual(result["p1"], result["p2"])

    def test_mrugesh(self):
        result = play(player, mrugesh, 1000)
        self.assertGreaterEqual(result["p1"], result["p2"])

    def test_kris(self):
        result = play(player, kris, 1000)
        self.assertGreaterEqual(result["p1"], result["p2"])

    def test_abbey(self):
        result = play(player, abbey, 1000)
        self.assertGreaterEqual(result["p1"], result["p2"])

if __name__ == "__main__":
    unittest.main()
