import tensorflow as tf
import numpy as np
import random

# Define constants for moves
MOVES = {'R': 0, 'P': 1, 'S': 2}
REVERSE_MOVES = {0: 'R', 1: 'P', 2: 'S'}
model = None  # Global model variable

def generate_data(num_sequences=1000, sequence_length=5):
    """Generate training data for the RPS model."""
    data = []
    labels = []
    for _ in range(num_sequences):
        sequence = [random.choice(['R', 'P', 'S']) for _ in range(sequence_length)]
        data.append([MOVES[move] for move in sequence[:-1]])  # Last move is for prediction
        labels.append(MOVES[sequence[-1]])
    return np.array(data), np.array(labels)

def build_model():
    """Build and compile the RPS prediction model."""
    model = tf.keras.models.Sequential([
        tf.keras.layers.Flatten(input_shape=(4, 3)),
        tf.keras.layers.Dense(16, activation='relu'),
        tf.keras.layers.Dense(16, activation='relu'),
        tf.keras.layers.Dense(3, activation='softmax')
    ])
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

def train_model():
    """Train the model using generated data."""
    global model
    x_train, y_train = generate_data()
    x_train = tf.keras.utils.to_categorical(x_train, num_classes=3)  # One-hot encoding
    y_train = tf.keras.utils.to_categorical(y_train, num_classes=3)
    
    model = build_model()
    model.fit(x_train, y_train, epochs=20, batch_size=32)
    
def predict_next_move(opponent_history):
    """Predict the opponent's next move based on history."""
    if len(opponent_history) < 4:
        return random.choice(['R', 'P', 'S'])  # Not enough data, play randomly
    
    # Prepare the input data for prediction
    recent_moves = opponent_history[-4:]
    recent_moves_encoded = tf.keras.utils.to_categorical(recent_moves, num_classes=3).reshape(1, 4, 3)
    
    # Predict the next move
    prediction = model.predict(recent_moves_encoded)
    predicted_move = np.argmax(prediction)
    return REVERSE_MOVES[predicted_move]

def player(prev_play, opponent_history=[]):
    """Main player function that selects the move to play."""
    if prev_play:
        opponent_history.append(MOVES[prev_play])
    
    # Train model if not trained yet
    if model is None:
        train_model()
    
    # Predict the next move and return the counter-move
    predicted_move = predict_next_move(opponent_history)
    if predicted_move == 'R':
        return 'P'  # Counter Rock
    elif predicted_move == 'P':
        return 'S'  # Counter Paper
    else:
        return 'R'  # Counter Scissors
